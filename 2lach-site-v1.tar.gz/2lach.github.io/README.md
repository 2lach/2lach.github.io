# Hello good people

### This is the codebase for my personal page 
#### and like so many things in life it is always work in progress

<p>Everything is pretty much built and setup from scratch
currently its a react site -v 16.4
with webpack as the bundler and some other stuff </p>

<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/React-icon.svg/2000px-React-icon.svg.png" width="auto" height="80"/><img alt="babel" src="https://camo.githubusercontent.com/d9c375f995662971a3872419c94643e6e7f565d6/68747470733a2f2f63646e2e776f726c64766563746f726c6f676f2e636f6d2f6c6f676f732f7765627061636b2d69636f6e2e737667" alt="webpack" width="auto" height="80" style="padding-right:25px"/><img alt="prettier" src="https://pbs.twimg.com/profile_images/925713973789560832/uiRIO5mN_400x400.jpg" width="auto" height="80"/><img width="auto" height="80" src="https://pbs.twimg.com/profile_images/567000326444556290/-1wfGjNw.png" /><br/>
<img src="https://img.shields.io/github/license/mashape/apistatus.svg"/>


images:
Mobile landscape - Photo by asoggetti from Unsplash
<!--
(currently location names of not named)



    <a href="#backers" alt="Backers on Open Collective">
        <img src="https://opencollective.com/shields/backers/badge.svg" /></a>
    <a href="#sponsors" alt="Sponsors on Open Collective">
        <img src="https://opencollective.com/shields/sponsors/badge.svg" /></a>
    <a href="https://circleci.com/gh/badges/shields/tree/master">
        <img src="https://img.shields.io/circleci/project/github/badges/shields/master.svg"
            alt="build status"></a>
    <a href="https://github.com/badges/shields/compare/gh-pages...master">
        <img src="https://img.shields.io/github/commits-since/badges/shields/gh-pages.svg?label=commits%20to%20be%20deployed"
            alt="commits to be deployed"></a>
    <a href="https://lgtm.com/projects/g/badges/shields/alerts/">
        <img src="https://img.shields.io/lgtm/alerts/g/badges/shields.svg?logo=lgtm&logoWidth=18"
            alt="Total alerts"/></a>
    <a href="https://discord.gg/HjJCwm5">
        <img src="https://img.shields.io/discord/308323056592486420.svg?logo=discord"
            alt="chat on Discord"></a>
    <a href="https://twitter.com/intent/follow?screen_name=shields_io">
        <img src="https://img.shields.io/twitter/follow/shields_io.svg?style=social&logo=twitter"
            alt="follow on Twitter"></a>

-->

It looks atm like this:

<img src="https://raw.githubusercontent.com/2lach/2lach.github.io/master/2lach.com.jpg" alt='yo moma smells nice' />
