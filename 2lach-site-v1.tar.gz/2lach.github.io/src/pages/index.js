import React from "react";
import ReactDOM from "react-dom";
import App from "../components/App.js";
// https://www.gatsbyjs.org/docs/porting-from-create-react-app-to-gatsby/#what-is-create-react-app
ReactDOM.render(<App />, document.getElementById("root"));
