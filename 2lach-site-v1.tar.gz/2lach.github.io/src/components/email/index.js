import React from "react";
import "./style.css";
/* Letter design by Oksana_ -> https://codepen.io/Oksana_/*/

const Email = () => {
  return (
    <div className="wrapper">
      <div className="mail">
        <div className="cover" />
        <div className="letter">
          <h1>Click here to contact me</h1>
        </div>
      </div>
    </div>
  );
};

export default Email;
